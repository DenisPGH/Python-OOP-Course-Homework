from project.movie_specification.movie import Movie
from project.user import User


class Thriller(Movie):
    def __init__(self, title: str, year: int, owner: User, age_restriction=16):
        super().__init__(title, year, owner, age_restriction)

    @property
    def age_restriction(self):
        return self.age_restriction

    @age_restriction.setter
    def age_restriction(self, value):
        if value<16:
            raise ValueError("Thriller movies must be restricted for audience under 16 years!")
        self.age_restriction=value

    def details(self):
        result=''
        result+=f"Thriller - Title:{self.title}," \
                f" Year:{self.year}, " \
                f"Age restriction:{self.age_restriction}," \
                f" Likes:{self.likes}, " \
                f"Owned by:{self.owner}"
        return result