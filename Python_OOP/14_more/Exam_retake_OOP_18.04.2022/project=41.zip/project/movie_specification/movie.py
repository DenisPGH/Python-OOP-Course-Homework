from project.user import User


class Movie:
    def __init__(self,title:str,year:int,owner: User,age_restriction: int):
        self.title = title
        self.year = year
        self.owner = owner
        self.age_restriction = age_restriction
        self.likes = 0

    @property
    def title(self):
        return self.title
        
    @title.setter
    def title(self, value):
        if value=="":
            raise ValueError("The title cannot be empty string!")
        self.title=value
        
    @property
    def year(self):
       return self.year
    
    @year.setter
    def year(self, value):
        if value<1888:
            raise ValueError("Movies weren't made before 1888!")
        self.year=value
        
    @property
    def owner(self):
        return self.owner
    
    @owner.setter
    def owner(self, value):
        if not isinstance(value,User):
            raise ValueError("The owner must be an object of type User!")
        self.owner=value

    def details(self):
        pass
            