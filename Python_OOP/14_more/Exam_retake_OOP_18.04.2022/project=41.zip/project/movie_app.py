from project.movie_specification.movie import Movie


class MovieApp:
    def __init__(self):
        self.movies_collection=[]
        self.users_collection=[]

    def register_user(username: str, age: int):
        pass


    def upload_movie(username: str, movie: Movie):
        pass

    def edit_movie(username: str, movie: Movie, **kwargs):
        pass

    def delete_movie(username: str, movie: Movie):
        pass

    def like_movie(username: str, movie: Movie):
        pass

    def dislike_movie(username: str, movie: Movie):
        pass

    def display_movies(self):
        pass

    def __str__(self):
        pass

