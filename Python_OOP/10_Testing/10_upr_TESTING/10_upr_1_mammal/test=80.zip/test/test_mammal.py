"""Submit only the test folder"""
import unittest

from project.mammal import Mammal


class TestMammal(unittest.TestCase):
    name="deni"
    type="mam"
    sound="HHHH"
    __kingdom = "animals"
    def test_constructor__if_gived_values_are_corect(self):
        deni=Mammal(self.name,self.type,self.sound)
        self.assertEqual(self.name,deni.name)
        self.assertEqual(self.type,deni.type)
        self.assertEqual(self.sound,deni.sound)
    def test_make_sound__should_return_string(self):
        deni = Mammal(self.name, self.type, self.sound)
        result=deni.make_sound()
        self.assertEqual(f"{self.name} makes {self.sound}",result)

    def test_get_kingdom__return_string(self):
        deni = Mammal(self.name, self.type, self.sound)
        result = deni.get_kingdom()
        self.assertEqual(self.__kingdom,result)

    def test_info_return_string(self):
        deni = Mammal(self.name, self.type, self.sound)
        result = deni.info()
        self.assertEqual(f"{self.name} is of type {self.type}", result)



if __name__=="__main__":
    unittest.main()



