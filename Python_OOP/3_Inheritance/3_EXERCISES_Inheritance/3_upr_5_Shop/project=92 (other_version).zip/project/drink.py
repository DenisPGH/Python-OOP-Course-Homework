"""In the file drink.py, the class Drink should be implemented.
 The class should inherit from the Product class. An instance of the
  Drink class will have a name and a quantity of 10."""
from project.product import Product
class Drink(Product):
    def __init__(self,name,quantity=10):
        super().__init__(name,quantity)