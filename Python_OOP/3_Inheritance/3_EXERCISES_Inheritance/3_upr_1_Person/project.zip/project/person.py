# Every person receives name and age upon initialization. Your task is to model the application.

class Person:
    def __init__(self,name, age):
        self.name = name
        self.age = age