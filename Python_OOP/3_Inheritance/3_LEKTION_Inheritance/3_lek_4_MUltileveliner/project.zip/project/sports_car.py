# •	SportsCar with a single method race() that returns: "racing...".
from project.car import Car



class SportsCar(Car):
    def race(self):
        return "racing..."