#•	Vehicle with a single method move() that returns: "moving..."

class Vehicle:
    def move(self):
        return  "moving..."