 # •	Car with a single method drive() that returns: "driving..."
from project.vehicle import Vehicle
class Car(Vehicle):
    def drive(self):
        return "driving..."