# •	Employee with a single method get_fired() that returns: "fired..."


class Employee:
    def get_fired(self):
        return "fired..."