# •	Person with a single method sleep() that returns: "sleeping..."

class Person:
    def sleep(self):
        return "sleeping..."