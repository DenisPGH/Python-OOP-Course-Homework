# •	Animal with a single method eat() that returns: "eating..."

class Animal:
    def eat(self):
        return  "eating..."