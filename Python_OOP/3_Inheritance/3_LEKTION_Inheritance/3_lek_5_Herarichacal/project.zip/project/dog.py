# •	Dog with a single method bark() that returns: "barking..."
from project.animal import Animal
class Dog(Animal):
    def bark(self):
        return "barking..."