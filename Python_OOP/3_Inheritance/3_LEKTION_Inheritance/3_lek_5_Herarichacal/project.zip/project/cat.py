# •	Cat with a single method meow() that returns: "meowing..."
from  project.animal import Animal
class Cat(Animal):
    def meow(self):
        return "meowing..."