"""HotBeverage and ColdBeverage are beverages."""
"""HotBeverage and ColdBeverage are beverages."""
from beverage import Beverage


class ColdBeverage(Beverage):
    pass