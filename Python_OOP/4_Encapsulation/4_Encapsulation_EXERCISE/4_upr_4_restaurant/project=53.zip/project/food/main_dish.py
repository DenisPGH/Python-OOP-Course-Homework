"""Starter, MainDish, and Dessert are food:
•	The Dessert class should have an additional private attribute - calories - float and its subsequent getter
"""
from project.food.food import Food


class MainDish(Food):
    pass