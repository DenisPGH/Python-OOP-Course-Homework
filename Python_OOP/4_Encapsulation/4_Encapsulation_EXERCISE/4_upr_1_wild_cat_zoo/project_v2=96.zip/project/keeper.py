"""The Keeper, the Caretaker, and the Vet classes should inherit from the Worker class."""
from project.worker import Worker


class Keeper(Worker):
    pass
